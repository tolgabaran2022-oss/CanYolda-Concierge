import { Icon } from "@/components/Icon";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useAuth } from "@/contexts/AuthContext";
import { usePets, type Pet } from "@/contexts/PetsContext";
import {
  apiGetVaccinations,
  apiGetAppointments,
  apiGetNutrition,
  buildReminders,
  type ApiVaccination,
  type ApiAppointment,
  type ApiNutrition,
  type ApiReminder,
} from "@/lib/petManagementApi";
import {
  buildPetMeta,
  buildPetSubtitle,
} from "@/utils/petFormatters";

/* ── Design tokens ──────────────────────────────────────────────────────────── */
const C = {
  purple:      "#7C45D9",
  purpleDark:  "#5F319F",
  purpleLight: "#F7F3FD",
  purpleBorder:"#CDB8EF",
  text:        "#1D1733",
  textSec:     "#8C8699",
  card:        "#FFFFFF",
  border:      "#EDE7F3",
  bg:          "#F5F2FB",
  orange:      "#EFA547",
  orangeBg:    "#FFF7ED",
  green:       "#43B96C",
  greenBg:     "#EDFFF4",
  red:         "#E55D6F",
};

const SHADOW_SM = Platform.select({
  ios:     { shadowColor: "#4B267D", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 8 },
  android: { elevation: 2 },
  default: {},
});
const SHADOW_MD = Platform.select({
  ios:     { shadowColor: "#4B267D", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.10, shadowRadius: 14 },
  android: { elevation: 4 },
  default: {},
});

/* ── Helpers ─────────────────────────────────────────────────────────────────── */
function formatReminderDate(dateStr: string): string {
  if (!dateStr) return "—";
  try {
    return new Date(dateStr).toLocaleDateString("tr-TR", {
      day: "numeric", month: "long", year: "numeric",
    });
  } catch { return dateStr; }
}

function formatDateShort(dateStr: string): string {
  if (!dateStr) return "—";
  try {
    return new Date(dateStr).toLocaleDateString("tr-TR", {
      day: "numeric", month: "short", year: "numeric",
    });
  } catch { return dateStr; }
}

/* ══════════════════════════════════════════════════════════════════════════════
   1. EMPTY STATE (no pets)
══════════════════════════════════════════════════════════════════════════════ */
function NoPetsState({ onAdd }: { onAdd: () => void }) {
  return (
    <View style={np.root}>
      <LinearGradient colors={["#EDE5FF", "#F5F0FF"]} style={np.circle}>
        <Icon name="paw" size={48} color={C.purple} />
      </LinearGradient>
      <Text style={np.title}>Evcil dostunu ekle</Text>
      <Text style={np.sub}>
        Aşılarını, randevularını, sağlık ve beslenme{"\n"}bilgilerini tek yerden yönet.
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Yeni evcil hayvan ekle"
        style={({ pressed }) => [np.btn, { opacity: pressed ? 0.85 : 1 }]}
        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onAdd(); }}
      >
        <LinearGradient colors={["#9B6EE8", C.purple]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={np.btnGrad}>
          <Icon name="add-circle-outline" size={18} color="#fff" />
          <Text style={np.btnTxt}>Evcil Hayvan Ekle</Text>
        </LinearGradient>
      </Pressable>
    </View>
  );
}
const np = StyleSheet.create({
  root:    { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 40, gap: 16, paddingBottom: 80 },
  circle:  { width: 120, height: 120, borderRadius: 60, alignItems: "center", justifyContent: "center", marginBottom: 8 },
  title:   { fontSize: 22, fontFamily: "Inter_700Bold", color: C.text, textAlign: "center", letterSpacing: -0.4 },
  sub:     { fontSize: 14, fontFamily: "Inter_400Regular", color: C.textSec, textAlign: "center", lineHeight: 22 },
  btn:     { borderRadius: 50, overflow: "hidden", marginTop: 8 },
  btnGrad: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 15, paddingHorizontal: 32 },
  btnTxt:  { fontSize: 15, fontFamily: "Inter_700Bold", color: "#fff" },
});

/* ══════════════════════════════════════════════════════════════════════════════
   2. PET PROFILE CARD
══════════════════════════════════════════════════════════════════════════════ */
function PetProfileCard({
  pets,
  selectedIndex,
  onSelectIndex,
  onAdd,
  onEdit,
}: {
  pets: Pet[];
  selectedIndex: number;
  onSelectIndex: (i: number) => void;
  onAdd: () => void;
  onEdit: () => void;
}) {
  const pet = pets[selectedIndex]!;
  const subtitle = buildPetSubtitle(pet.type, pet.breed, pet.gender);
  const meta     = buildPetMeta(pet.birthDate, pet.age, pet.weight);

  return (
    <View style={pc.wrap}>
      {/* Profile card */}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Evcil hayvan detayını aç"
        style={({ pressed }) => [pc.card, SHADOW_MD, { opacity: pressed ? 0.95 : 1 }]}
        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onEdit(); }}
      >
        <View style={pc.row}>
          {/* Avatar */}
          <View style={pc.avatarRing}>
            {pet.image ? (
              <Image
                source={{ uri: pet.image }}
                style={pc.avatar}
                contentFit="cover"
                transition={200}
              />
            ) : (
              <LinearGradient colors={["#A07FE0", C.purple]} style={pc.avatarFallback}>
                <Icon name="paw" size={30} color="rgba(255,255,255,0.9)" />
              </LinearGradient>
            )}
          </View>

          {/* Info */}
          <View style={pc.info}>
            <View style={pc.nameRow}>
              <Text style={pc.name} numberOfLines={1}>{pet.name}</Text>
              <Icon name="checkmark-circle" size={18} color="#5856D6" />
            </View>

            {subtitle ? (
              <Text style={pc.subtitle} numberOfLines={1}>{subtitle}</Text>
            ) : null}

            {meta ? (
              <View style={pc.pill}>
                <Text style={pc.pillTxt}>{meta}</Text>
              </View>
            ) : null}
          </View>

          {/* Dropdown arrow */}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Evcil hayvan değiştir"
            hitSlop={12}
            onPress={(e) => {
              e.stopPropagation?.();
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
          >
            <Icon name="chevron-down" size={20} color={C.textSec} />
          </Pressable>
        </View>
      </Pressable>

      {/* Dot indicators — only when >1 pet */}
      {pets.length > 1 && (
        <View style={pc.dots}>
          {pets.map((_, i) => (
            <Pressable
              key={i}
              hitSlop={10}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onSelectIndex(i); }}
            >
              <View style={[pc.dot, i === selectedIndex && pc.dotActive]} />
            </Pressable>
          ))}
        </View>
      )}

      {/* Add pet button */}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Yeni evcil hayvan ekle"
        style={({ pressed }) => [pc.addBtn, { opacity: pressed ? 0.82 : 1 }]}
        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onAdd(); }}
      >
        <Icon name="add-circle-outline" size={18} color={C.purple} />
        <Text style={pc.addTxt}>Evcil Hayvan Ekle</Text>
      </Pressable>
    </View>
  );
}
const pc = StyleSheet.create({
  wrap:          { marginHorizontal: 20, marginTop: 16 },
  card:          {
    backgroundColor: C.card,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: C.border,
    minHeight: 110,
  },
  row:           { flexDirection: "row", alignItems: "center", padding: 16, gap: 14 },
  avatarRing:    {
    width: 78, height: 78, borderRadius: 39,
    borderWidth: 2.5, borderColor: C.purple,
    alignItems: "center", justifyContent: "center",
    flexShrink: 0,
    overflow: "hidden",
  },
  avatar:        { width: 73, height: 73, borderRadius: 36 },
  avatarFallback:{ width: 73, height: 73, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  info:          { flex: 1, gap: 5 },
  nameRow:       { flexDirection: "row", alignItems: "center", gap: 6 },
  name:          { fontSize: 20, fontFamily: "Inter_700Bold", color: C.text, letterSpacing: -0.4, flex: 1 },
  subtitle:      { fontSize: 13, fontFamily: "Inter_400Regular", color: C.textSec, lineHeight: 18 },
  pill:          { alignSelf: "flex-start", backgroundColor: `${C.purple}14`, borderRadius: 50, paddingHorizontal: 10, paddingVertical: 4 },
  pillTxt:       { fontSize: 12, fontFamily: "Inter_600SemiBold", color: C.purple },
  dots:          { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 7, marginTop: 14 },
  dot:           { width: 7, height: 7, borderRadius: 3.5, backgroundColor: "#D8D0E8" },
  dotActive:     { width: 20, height: 7, borderRadius: 4, backgroundColor: C.purple },
  addBtn:        {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    marginTop: 14,
    height: 54,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: C.purpleBorder,
    borderStyle: "dashed",
    backgroundColor: "#F7F2FF",
  },
  addTxt:        { fontSize: 14, fontFamily: "Inter_600SemiBold", color: C.purple },
});

/* ══════════════════════════════════════════════════════════════════════════════
   3. QUICK STATUS CARDS
══════════════════════════════════════════════════════════════════════════════ */
function QuickStatusCards({
  vaccinations,
  appointments,
  nutrition,
  petId,
  onNav,
}: {
  vaccinations: ApiVaccination[];
  appointments: ApiAppointment[];
  nutrition: ApiNutrition | null;
  petId: string;
  onNav: (route: string) => void;
}) {
  const nextVacc = vaccinations
    .filter((v) => v.nextDueDate)
    .sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate))[0];

  const nextAppt = appointments
    .filter((a) => a.status === "upcoming")
    .sort((a, b) => a.appointmentDate.localeCompare(b.appointmentDate))[0];

  let daysLeft: number | null = null;
  let stockKg = "";
  if (nutrition && nutrition.dailyAmountGrams > 0) {
    daysLeft = Math.floor(nutrition.remainingAmountGrams / nutrition.dailyAmountGrams);
    const kg = nutrition.remainingAmountGrams / 1000;
    stockKg = `${kg.toLocaleString("tr-TR", { maximumFractionDigits: 1 })} kg`;
  }

  const cards = [
    {
      label:     "Sonraki Aşı",
      value:     nextVacc?.vaccineName ?? "Kayıt yok",
      secondary: nextVacc ? formatDateShort(nextVacc.nextDueDate) : "Aşı ekle",
      icon:      "calendar-outline" as const,
      color:     C.orange,
      bg:        C.orangeBg,
      route:     `/evcilim/${petId}/vaccinations`,
      isEmpty:   !nextVacc,
    },
    {
      label:     "Yaklaşan Randevu",
      value:     nextAppt?.title ?? "Randevu yok",
      secondary: nextAppt ? formatDateShort(nextAppt.appointmentDate) : "Randevu oluştur",
      icon:      "calendar-outline" as const,
      color:     C.purple,
      bg:        C.purpleLight,
      route:     `/evcilim/${petId}/appointments`,
      isEmpty:   !nextAppt,
    },
    {
      label:     "Mama Durumu",
      value:     daysLeft !== null ? `${daysLeft} gün kaldı` : "Kayıt yok",
      secondary: stockKg || "Beslenme ekle",
      icon:      "nutrition-outline" as const,
      color:     C.green,
      bg:        C.greenBg,
      route:     `/evcilim/${petId}/nutrition`,
      isEmpty:   daysLeft === null,
    },
  ];

  return (
    <View style={qs.section}>
      <Text style={qs.title}>Hızlı Durum</Text>
      <View style={qs.row}>
        {cards.map((c) => (
          <Pressable
            key={c.label}
            accessibilityRole="button"
            style={({ pressed }) => [qs.card, { backgroundColor: c.bg }, pressed && { opacity: 0.84 }]}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onNav(c.route); }}
          >
            <Text style={[qs.label, { color: c.color }]} numberOfLines={2}>{c.label}</Text>
            <Text
              style={[qs.value, c.isEmpty && qs.valueEmpty]}
              numberOfLines={2}
            >
              {c.value}
            </Text>
            <View style={qs.bottom}>
              <Icon name={c.icon} size={14} color={c.color} />
              <Text style={[qs.secondary, { color: c.isEmpty ? c.color : C.textSec }]} numberOfLines={1}>
                {c.secondary}
              </Text>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
const qs = StyleSheet.create({
  section:   { marginHorizontal: 20, marginTop: 24 },
  title:     { fontSize: 18, fontFamily: "Inter_700Bold", color: C.text, marginBottom: 12, letterSpacing: -0.3 },
  row:       { flexDirection: "row", gap: 10 },
  card:      { flex: 1, borderRadius: 18, padding: 13, minHeight: 112, justifyContent: "space-between" },
  label:     { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 0.2, marginBottom: 4 },
  value:     { fontSize: 13, fontFamily: "Inter_700Bold", color: C.text, lineHeight: 18, flex: 1 },
  valueEmpty:{ color: C.textSec, fontFamily: "Inter_500Medium" },
  bottom:    { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 },
  secondary: { fontSize: 11, fontFamily: "Inter_500Medium", color: C.textSec, flex: 1 },
});

/* ══════════════════════════════════════════════════════════════════════════════
   4. MANAGEMENT GRID (4 cols × 2 rows, all purple icons)
══════════════════════════════════════════════════════════════════════════════ */
type GridItem = {
  key:   string;
  label: string;
  icon:  string;
  route: string;
  badge?: number;
};

function ManagementGrid({
  petId,
  vaccinations,
  appointments,
  onNav,
}: {
  petId: string;
  vaccinations: ApiVaccination[];
  appointments: ApiAppointment[];
  onNav: (route: string) => void;
}) {
  const overdueVacc  = vaccinations.filter((v) => v.status === "overdue").length;
  const upcomingAppt = appointments.filter((a) => a.status === "upcoming").length;

  const GRID: GridItem[] = [
    { key: "id",           label: "Kimlik",    icon: "id-card-outline",          route: `/evcilim/${petId}/identification` },
    { key: "health",       label: "Sağlık",    icon: "heart-outline",            route: `/evcilim/${petId}/vaccinations` },
    { key: "vaccinations", label: "Aşılar",    icon: "shield-checkmark-outline", route: `/evcilim/${petId}/vaccinations`, badge: overdueVacc || undefined },
    { key: "appointments", label: "Randevular", icon: "calendar-outline",         route: `/evcilim/${petId}/appointments`, badge: upcomingAppt || undefined },
    { key: "nutrition",    label: "Beslenme",   icon: "nutrition-outline",        route: `/evcilim/${petId}/nutrition` },
    { key: "documents",    label: "Belgeler",   icon: "document-text-outline",   route: `/evcilim/${petId}/notes` },
    { key: "medications",  label: "İlaçlar",    icon: "medical-outline",          route: `/evcilim/${petId}/notes` },
    { key: "notes",        label: "Notlar",     icon: "pencil-outline",           route: `/evcilim/${petId}/notes` },
  ];

  return (
    <View style={mg.section}>
      <Text style={mg.title}>Yönetim</Text>
      <View style={mg.grid}>
        {GRID.map((item) => (
          <Pressable
            key={item.key}
            accessibilityRole="button"
            accessibilityLabel={`${item.label} ekranını aç`}
            style={({ pressed }) => [mg.cell, pressed && { opacity: 0.75 }]}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onNav(item.route); }}
          >
            <View style={mg.iconBox}>
              <Icon name={item.icon} size={22} color={C.purple} />
              {item.badge !== undefined && item.badge > 0 && (
                <View style={mg.badge}>
                  <Text style={mg.badgeTxt}>{item.badge}</Text>
                </View>
              )}
            </View>
            <Text style={mg.cellLabel} numberOfLines={2}>{item.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
const mg = StyleSheet.create({
  section:   { marginHorizontal: 20, marginTop: 24 },
  title:     { fontSize: 18, fontFamily: "Inter_700Bold", color: C.text, marginBottom: 12, letterSpacing: -0.3 },
  grid:      { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 12 },
  cell:      {
    width: "23.5%",
    minHeight: 88,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.card,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: C.border,
    paddingVertical: 12,
    paddingHorizontal: 4,
    gap: 8,
    ...SHADOW_SM,
  },
  iconBox:   {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: `${C.purple}14`,
    alignItems: "center", justifyContent: "center",
    position: "relative",
  },
  badge:     { position: "absolute", top: -3, right: -3, width: 16, height: 16, borderRadius: 8, backgroundColor: C.red, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: C.card },
  badgeTxt:  { fontSize: 9, fontFamily: "Inter_700Bold", color: "#fff" },
  cellLabel: { fontSize: 11, fontFamily: "Inter_500Medium", color: C.text, textAlign: "center", lineHeight: 15, paddingHorizontal: 4 },
});

/* ══════════════════════════════════════════════════════════════════════════════
   5. UPCOMING REMINDERS
══════════════════════════════════════════════════════════════════════════════ */
function UpcomingReminders({
  reminders,
  petId,
  onNav,
}: {
  reminders: ApiReminder[];
  petId: string;
  onNav: (route: string) => void;
}) {
  const upcoming = reminders
    .filter((r) => {
      try { return new Date(r.date) >= new Date(new Date().setHours(0, 0, 0, 0)); }
      catch { return true; }
    })
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 3);

  return (
    <View style={ur.section}>
      <View style={ur.header}>
        <Text style={ur.title}>Yaklaşan Hatırlatmalar</Text>
        <Pressable
          hitSlop={12}
          accessibilityRole="button"
          accessibilityLabel="Tüm hatırlatmaları görüntüle"
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onNav(`/evcilim/${petId}/notes`); }}
        >
          <Text style={ur.seeAll}>Tümünü Gör</Text>
        </Pressable>
      </View>

      {upcoming.length === 0 ? (
        <View style={ur.emptyCard}>
          <View style={ur.emptyIconWrap}>
            <Icon name="calendar-outline" size={26} color={C.green} />
          </View>
          <View style={ur.emptyText}>
            <Text style={ur.emptyTitle}>Yaklaşan hatırlatman yok</Text>
            <Text style={ur.emptySub}>Aşı, randevu veya bakım hatırlatıcısı ekleyebilirsin.</Text>
          </View>
          <Pressable
            hitSlop={8}
            style={ur.emptyBtn}
            accessibilityRole="button"
            onPress={() => onNav(`/evcilim/${petId}/vaccinations`)}
          >
            <Text style={ur.emptyBtnTxt}>Hatırlatıcı Ekle</Text>
          </Pressable>
        </View>
      ) : (
        <View style={ur.list}>
          {upcoming.map((r) => (
            <Pressable
              key={r.id}
              accessibilityRole="button"
              style={({ pressed }) => [ur.item, pressed && { opacity: 0.85 }]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
            >
              <View style={[ur.iconWrap, { backgroundColor: `${r.color}18` }]}>
                <Icon name={r.icon} size={18} color={r.color} />
              </View>
              <View style={ur.mid}>
                <Text style={ur.itemTitle} numberOfLines={1}>{r.title}</Text>
                <Text style={ur.itemDate}>{formatReminderDate(r.date)}</Text>
              </View>
              <View style={[ur.alarmWrap, { backgroundColor: `${r.color}18` }]}>
                <Icon name="alarm-outline" size={18} color={r.color} />
              </View>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}
const ur = StyleSheet.create({
  section:      { marginHorizontal: 20, marginTop: 24, marginBottom: 8 },
  header:       { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  title:        { fontSize: 18, fontFamily: "Inter_700Bold", color: C.text, letterSpacing: -0.3 },
  seeAll:       { fontSize: 13, fontFamily: "Inter_600SemiBold", color: C.purple },
  emptyCard:    {
    backgroundColor: C.card,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    minHeight: 110,
    ...SHADOW_SM,
  },
  emptyIconWrap:{ width: 44, height: 44, borderRadius: 22, backgroundColor: `${C.green}14`, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  emptyText:    { flex: 1 },
  emptyTitle:   { fontSize: 14, fontFamily: "Inter_600SemiBold", color: C.text, marginBottom: 4 },
  emptySub:     { fontSize: 12, fontFamily: "Inter_400Regular", color: C.textSec, lineHeight: 17 },
  emptyBtn:     { paddingHorizontal: 12, paddingVertical: 8, backgroundColor: `${C.purple}12`, borderRadius: 10, flexShrink: 0 },
  emptyBtnTxt:  { fontSize: 12, fontFamily: "Inter_600SemiBold", color: C.purple },
  list:         { gap: 10 },
  item:         {
    flexDirection: "row", alignItems: "center", gap: 12,
    backgroundColor: C.card, borderRadius: 18, padding: 14,
    borderWidth: 1, borderColor: C.border,
    ...SHADOW_SM,
  },
  iconWrap:     { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  mid:          { flex: 1 },
  itemTitle:    { fontSize: 14, fontFamily: "Inter_600SemiBold", color: C.text },
  itemDate:     { fontSize: 12, fontFamily: "Inter_400Regular", color: C.textSec, marginTop: 2 },
  alarmWrap:    { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", flexShrink: 0 },
});

/* ══════════════════════════════════════════════════════════════════════════════
   6. LOADING SKELETON
══════════════════════════════════════════════════════════════════════════════ */
function Skeleton({ w, h, r = 12 }: { w: number | string; h: number; r?: number }) {
  return <View style={{ width: w as number, height: h, borderRadius: r, backgroundColor: "#EDE7F3" }} />;
}

function LoadingSkeleton() {
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 16, paddingBottom: 80 }} scrollEnabled={false}>
      <View style={{ marginHorizontal: 20 }}>
        <View style={[{ backgroundColor: "#fff", borderRadius: 24, borderWidth: 1, borderColor: "#EDE7F3", padding: 16, flexDirection: "row", gap: 14, alignItems: "center" }, SHADOW_MD]}>
          <View style={{ width: 78, height: 78, borderRadius: 39, backgroundColor: "#EDE7F3" }} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton w={120} h={20} r={6} />
            <Skeleton w={160} h={14} r={6} />
            <Skeleton w={100} h={26} r={13} />
          </View>
        </View>
      </View>
      <View style={{ marginHorizontal: 20, marginTop: 24 }}>
        <Skeleton w={120} h={20} r={6} />
        <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
          {[0, 1, 2].map((i) => (
            <View key={i} style={{ flex: 1, height: 112, borderRadius: 18, backgroundColor: "#EDE7F3" }} />
          ))}
        </View>
      </View>
      <View style={{ marginHorizontal: 20, marginTop: 24 }}>
        <Skeleton w={80} h={20} r={6} />
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", gap: 12, marginTop: 12 }}>
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <View key={i} style={{ width: "23.5%", height: 88, borderRadius: 18, backgroundColor: "#EDE7F3" }} />
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

/* ══════════════════════════════════════════════════════════════════════════════
   7. MAIN EXPORTED COMPONENT
══════════════════════════════════════════════════════════════════════════════ */
export function EvcilimTab({ botPad }: { botPad: number }) {
  const { pets, isLoading: petsLoading, error: petsError, refresh: refreshPets } = usePets();
  const { user } = useAuth();
  const router   = useRouter();

  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);
  const [vaccinations, setVaccinations]   = useState<ApiVaccination[]>([]);
  const [appointments, setAppointments]   = useState<ApiAppointment[]>([]);
  const [nutrition, setNutrition]         = useState<ApiNutrition | null>(null);
  const [dataLoading, setDataLoading]     = useState(false);
  const [refreshing, setRefreshing]       = useState(false);

  const effectivePetId = selectedPetId ?? pets[0]?.id ?? null;
  const selectedPet    = pets.find((p) => p.id === effectivePetId) ?? pets[0] ?? null;
  const selectedIndex  = Math.max(0, pets.findIndex((p) => p.id === effectivePetId));

  const nav = useCallback(
    (route: string) => router.push(route as Parameters<typeof router.push>[0]),
    [router]
  );

  const loadData = useCallback(async (petId: string, userId: string) => {
    setDataLoading(true);
    try {
      const [v, a, n] = await Promise.all([
        apiGetVaccinations(petId, userId),
        apiGetAppointments(petId, userId),
        apiGetNutrition(petId, userId),
      ]);
      setVaccinations(v);
      setAppointments(a);
      setNutrition(n);
    } finally {
      setDataLoading(false);
    }
  }, []);

  useEffect(() => {
    if (selectedPet && user) {
      loadData(selectedPet.id, user.id);
    }
  }, [selectedPet?.id, user?.id, loadData]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await refreshPets();
    if (selectedPet && user) {
      await loadData(selectedPet.id, user.id);
    }
    setRefreshing(false);
  }, [refreshPets, selectedPet, user, loadData]);

  if (petsLoading) {
    return <LoadingSkeleton />;
  }

  if (petsError) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 16, paddingHorizontal: 40 }}>
        <Icon name="alert-circle-outline" size={48} color={C.red} />
        <Text style={{ fontSize: 16, fontFamily: "Inter_600SemiBold", color: C.text, textAlign: "center" }}>
          Evcil hayvan bilgileri yüklenemedi.
        </Text>
        <Pressable
          style={[{ paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14, backgroundColor: C.purple }]}
          onPress={refreshPets}
        >
          <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#fff" }}>Tekrar Dene</Text>
        </Pressable>
      </View>
    );
  }

  if (pets.length === 0) {
    return <NoPetsState onAdd={() => nav("/evcilim/add")} />;
  }

  const reminders = selectedPet ? buildReminders(vaccinations, appointments, nutrition) : [];

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingTop: 4, paddingBottom: botPad + 28 }}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={C.purple} />
      }
    >
      {/* Pet profile card */}
      <PetProfileCard
        pets={pets}
        selectedIndex={selectedIndex}
        onSelectIndex={(i) => setSelectedPetId(pets[i]!.id)}
        onAdd={() => nav("/evcilim/add")}
        onEdit={() => selectedPet && nav(`/evcilim/${selectedPet.id}`)}
      />

      {dataLoading ? (
        <View style={{ alignItems: "center", paddingTop: 48 }}>
          <ActivityIndicator color={C.purple} size="large" />
        </View>
      ) : selectedPet ? (
        <>
          <QuickStatusCards
            vaccinations={vaccinations}
            appointments={appointments}
            nutrition={nutrition}
            petId={selectedPet.id}
            onNav={nav}
          />
          <ManagementGrid
            petId={selectedPet.id}
            vaccinations={vaccinations}
            appointments={appointments}
            onNav={nav}
          />
          <UpcomingReminders
            reminders={reminders}
            petId={selectedPet.id}
            onNav={nav}
          />
        </>
      ) : null}
    </ScrollView>
  );
}
